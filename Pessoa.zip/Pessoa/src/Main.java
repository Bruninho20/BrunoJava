import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		Pessoa p = new Pessoa("Cleito", 21);
		Pessoa p2 = new Pessoa(30);

		int aux = 0;
		System.out.println("Qual construtor vc quer? 1 - nome e idade OU 2 - idade");
		aux = entrada.nextInt();

		if (aux == 1) {
			p.getDados();
		} else {
			aux = 2;
			p2.getIdade();
		}
	}
}
