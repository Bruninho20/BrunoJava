
public class Pessoa {

	String nome;
	int idade;

	public Pessoa(String nome, int idade) {
		this.nome = nome;
		this.idade = idade;
	}

	public Pessoa(int idade) {
		this.idade = idade;
	}

	public void getDados() {
		System.out.println("Nome: " + nome);
		System.out.println("Idade: " + idade);
	}

	public void getIdade() {
		System.out.println("Idade: " + idade);
	}

}
