
public class Moto {

	String marca;
	String modelo;
	int cilindradas;

	@Override
	public String toString() {
		String aux = "";
		aux += "Marca: " + marca + "\n";
		aux += "Modelo: " + modelo + "\n";
		aux += "Cilindradas: " + cilindradas + "\n";
		return aux;
	}

}
