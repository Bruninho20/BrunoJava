import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		Carro c = new Carro();
		Moto m1 = new Moto();

		System.out.println("Insira o fabricante do Carro: ");
		c.fabricante = entrada.next();
		System.out.println("Qual o modelo?: ");
		c.modelo = entrada.next();
		c.exibirDados();
		System.out.println("-------------------------------");

		System.out.println("Insira a marca da moto: ");
		m1.marca = entrada.next();
		System.out.println("Insira o modelo: ");
		m1.modelo = entrada.next();
		System.out.println("Insira as cilindradas: ");
		m1.cilindradas = entrada.nextInt();
		System.out.println("--------------------------------");
		System.out.println(m1.toString());

		entrada.close();
	}

}
