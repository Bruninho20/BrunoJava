
public class Carro {

	public String modelo ;
	String fabricante ;

	public void exibirDados() {
		System.out.println("Modelo: " + modelo);
		System.out.println("Fabricante: " + fabricante);

	}
}
