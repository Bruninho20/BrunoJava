package br.fiap.dao;

import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Produto;

public class ProdutoDAO extends DAO {

	// metodo para inserir produto
	public void inserir(Produto produto) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_produto values(produto_sequence.nextval, ?,?,?.?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produto.getProduto_id());
			ps.setString(2, produto.getNome());
			ps.setString(3, produto.getDesc());
			ps.setDouble(5, produto.getPreco());
			ps.setString(4, produto.getCategoria().getCategoria_id());
			ps.execute();
			conexao.desconectar();

		} catch (Exception e) {
			System.out.println("Erro ao inserir produto\n" + e);
		}
	}
	
	//metodo para listar os produtos cadastrados
	public List <Produto> listar(){
		List<Produto> lista = new ArrayList<>(); 
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		
		
		return lista;
	}
}
